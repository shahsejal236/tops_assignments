<!DOCTYPE html>
<html lang="en">




    <?php $__env->startSection('main_container'); ?>

<body>
    <!-- Page Loader -->
    
  
   <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
    <div class="container-fluid tm-mt-60">
    
        <div class="row tm-mb-50">
            <div class="col-lg-12 col-4 mb-5">
            <div class="text-center  tm-text-primary mb-5">
                       <h1>Login here</h1>
                    </div>
    
                <form id="contact-form" action="" method="POST" enctype="multipart/form-data" class="tm-contact-form mx-auto">

                <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="email" name="email" class="form-control rounded-0" placeholder="Email" required />
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control rounded-0" placeholder="password" required />
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" class="form-control rounded-0" placeholder="confirmpassword" required />
                    </div>
                    
                 
            
                    
                    <div class="text-center">
                        <button type="submit" value-="submit" class="btn btn-primary">Login</button>
                    </div>
                </form>                
            </div>
         

    
    
    <script src="<?php echo e(url('frontend/js/plugins.js')); ?>"></script>
    <script>
        $(window).on("load", function() {
            $('body').addClass('loaded');
        });
    </script>
</body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sejal\laravel\laravel_assi\resources\views/frontend/userlogin.blade.php ENDPATH**/ ?>