@extends('backend.layout.main')

@section('main_container') 
               <!-- dashboard inner -->
               <div class="midde_cont">
                  <div class="container-fluid">
                     <div class="row column_title">
                        <div class="col-md-12">
                           <div class="page_title">
                              <h2>Icons <small>( Font Awesome Icons )</small></h2>
                           </div>
                        </div>
                     </div>
                     <!-- row -->
                     <div class="row">
                        <!-- Gallery section -->
                        <div class="col-md-12">
                           <div class="white_shd full margin_bottom_30">
                              <div class="full graph_head">
                                 <div class="heading1 margin_0">
                                    <h2>Web Application Icons</h2>
                                 </div>
                              </div>
                              <div class="full icons_section padding_infor_info">
                                 <div class="row fontawesome-icons-list">
                                    <div class="fw_icon"><a href="#/check-circle"><i class="fa fa-check-circle"></i> fa-check-circle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/check-circle-o"><i class="fa fa-check-circle-o"></i> fa-check-circle-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/check-square"><i class="fa fa-check-square"></i> fa-check-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/check-square-o"><i class="fa fa-check-square-o"></i> fa-check-square-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/child"><i class="fa fa-child"></i> fa-child</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/circle"><i class="fa fa-circle"></i> fa-circle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/circle-o"><i class="fa fa-circle-o"></i> fa-circle-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/circle-o-notch"><i class="fa fa-circle-o-notch"></i> fa-circle-o-notch</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/circle-thin"><i class="fa fa-circle-thin"></i> fa-circle-thin</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/clock-o"><i class="fa fa-clock-o"></i> fa-clock-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/times"><i class="fa fa-close"></i> fa-close  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cloud"><i class="fa fa-cloud"></i> fa-cloud</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cloud-download"><i class="fa fa-cloud-download"></i> fa-cloud-download</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cloud-upload"><i class="fa fa-cloud-upload"></i> fa-cloud-upload</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/code"><i class="fa fa-code"></i> fa-code</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/code-fork"><i class="fa fa-code-fork"></i> fa-code-fork</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/coffee"><i class="fa fa-coffee"></i> fa-coffee</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cog"><i class="fa fa-cog"></i> fa-cog</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cogs"><i class="fa fa-cogs"></i> fa-cogs</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/comment"><i class="fa fa-comment"></i> fa-comment</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/comment-o"><i class="fa fa-comment-o"></i> fa-comment-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/comments"><i class="fa fa-comments"></i> fa-comments</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/comments-o"><i class="fa fa-comments-o"></i> fa-comments-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/compass"><i class="fa fa-compass"></i> fa-compass</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/copyright"><i class="fa fa-copyright"></i> fa-copyright</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/credit-card"><i class="fa fa-credit-card"></i> fa-credit-card</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/crop"><i class="fa fa-crop"></i> fa-crop</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/crosshairs"><i class="fa fa-crosshairs"></i> fa-crosshairs</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cube"><i class="fa fa-cube"></i> fa-cube</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cubes"><i class="fa fa-cubes"></i> fa-cubes</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cutlery"><i class="fa fa-cutlery"></i> fa-cutlery</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/tachometer"><i class="fa fa-dashboard"></i> fa-dashboard  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/database"><i class="fa fa-database"></i> fa-database</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/desktop"><i class="fa fa-desktop"></i> fa-desktop</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/dot-circle-o"><i class="fa fa-dot-circle-o"></i> fa-dot-circle-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/download"><i class="fa fa-download"></i> fa-download</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/pencil-square-o"><i class="fa fa-edit"></i> fa-edit  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/ellipsis-h"><i class="fa fa-ellipsis-h"></i> fa-ellipsis-h</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/ellipsis-v"><i class="fa fa-ellipsis-v"></i> fa-ellipsis-v</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/envelope"><i class="fa fa-envelope"></i> fa-envelope</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/envelope-o"><i class="fa fa-envelope-o"></i> fa-envelope-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/envelope-square"><i class="fa fa-envelope-square"></i> fa-envelope-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/eraser"><i class="fa fa-eraser"></i> fa-eraser</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/exchange"><i class="fa fa-exchange"></i> fa-exchange</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/exclamation"><i class="fa fa-exclamation"></i> fa-exclamation</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/exclamation-circle"><i class="fa fa-exclamation-circle"></i> fa-exclamation-circle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/exclamation-triangle"><i class="fa fa-exclamation-triangle"></i> fa-exclamation-triangle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/external-link"><i class="fa fa-external-link"></i> fa-external-link</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/external-link-square"><i class="fa fa-external-link-square"></i> fa-external-link-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/eye"><i class="fa fa-eye"></i> fa-eye</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/eye-slash"><i class="fa fa-eye-slash"></i> fa-eye-slash</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/eyedropper"><i class="fa fa-eyedropper"></i> fa-eyedropper</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/fax"><i class="fa fa-fax"></i> fa-fax</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/female"><i class="fa fa-female"></i> fa-female</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/fighter-jet"><i class="fa fa-fighter-jet"></i> fa-fighter-jet</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-archive-o"><i class="fa fa-file-archive-o"></i> fa-file-archive-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-audio-o"><i class="fa fa-file-audio-o"></i> fa-file-audio-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-code-o"><i class="fa fa-file-code-o"></i> fa-file-code-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-excel-o"><i class="fa fa-file-excel-o"></i> fa-file-excel-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-image-o"><i class="fa fa-file-image-o"></i> fa-file-image-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-video-o"><i class="fa fa-file-movie-o"></i> fa-file-movie-o  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-pdf-o"><i class="fa fa-file-pdf-o"></i> fa-file-pdf-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-image-o"><i class="fa fa-file-photo-o"></i> fa-file-photo-o  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-image-o"><i class="fa fa-file-picture-o"></i> fa-file-picture-o  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-powerpoint-o"><i class="fa fa-file-powerpoint-o"></i> fa-file-powerpoint-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-audio-o"><i class="fa fa-file-sound-o"></i> fa-file-sound-o  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-video-o"><i class="fa fa-file-video-o"></i> fa-file-video-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-word-o"><i class="fa fa-file-word-o"></i> fa-file-word-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-archive-o"><i class="fa fa-file-zip-o"></i> fa-file-zip-o  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/film"><i class="fa fa-film"></i> fa-film</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/filter"><i class="fa fa-filter"></i> fa-filter</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/fire"><i class="fa fa-fire"></i> fa-fire</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/fire-extinguisher"><i class="fa fa-fire-extinguisher"></i> fa-fire-extinguisher</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/flag"><i class="fa fa-flag"></i> fa-flag</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/flag-checkered"><i class="fa fa-flag-checkered"></i> fa-flag-checkered</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/flag-o"><i class="fa fa-flag-o"></i> fa-flag-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bolt"><i class="fa fa-flash"></i> fa-flash  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/flask"><i class="fa fa-flask"></i> fa-flask</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/folder"><i class="fa fa-folder"></i> fa-folder</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/folder-o"><i class="fa fa-folder-o"></i> fa-folder-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/folder-open"><i class="fa fa-folder-open"></i> fa-folder-open</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/folder-open-o"><i class="fa fa-folder-open-o"></i> fa-folder-open-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/frown-o"><i class="fa fa-frown-o"></i> fa-frown-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/futbol-o"><i class="fa fa-futbol-o"></i> fa-futbol-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/gamepad"><i class="fa fa-gamepad"></i> fa-gamepad</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/gavel"><i class="fa fa-gavel"></i> fa-gavel</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cog"><i class="fa fa-gear"></i> fa-gear  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cogs"><i class="fa fa-gears"></i> fa-gears  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/gift"><i class="fa fa-gift"></i> fa-gift</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/glass"><i class="fa fa-glass"></i> fa-glass</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/globe"><i class="fa fa-globe"></i> fa-globe</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/graduation-cap"><i class="fa fa-graduation-cap"></i> fa-graduation-cap</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/users"><i class="fa fa-group"></i> fa-group  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/hdd-o"><i class="fa fa-hdd-o"></i> fa-hdd-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/headphones"><i class="fa fa-headphones"></i> fa-headphones</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/heart"><i class="fa fa-heart"></i> fa-heart</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/heart-o"><i class="fa fa-heart-o"></i> fa-heart-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/history"><i class="fa fa-history"></i> fa-history</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/home"><i class="fa fa-home"></i> fa-home</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/picture-o"><i class="fa fa-image"></i> fa-image  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/inbox"><i class="fa fa-inbox"></i> fa-inbox</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/info"><i class="fa fa-info"></i> fa-info</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/info-circle"><i class="fa fa-info-circle"></i> fa-info-circle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/university"><i class="fa fa-institution"></i> fa-institution  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/key"><i class="fa fa-key"></i> fa-key</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/keyboard-o"><i class="fa fa-keyboard-o"></i> fa-keyboard-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/language"><i class="fa fa-language"></i> fa-language</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/laptop"><i class="fa fa-laptop"></i> fa-laptop</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/leaf"><i class="fa fa-leaf"></i> fa-leaf</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/gavel"><i class="fa fa-legal"></i> fa-legal  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/lemon-o"><i class="fa fa-lemon-o"></i> fa-lemon-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/level-down"><i class="fa fa-level-down"></i> fa-level-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/adjust"><i class="fa fa-adjust"></i> fa-adjust</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/anchor"><i class="fa fa-anchor"></i> fa-anchor</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/archive"><i class="fa fa-archive"></i> fa-archive</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/area-chart"><i class="fa fa-area-chart"></i> fa-area-chart</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrows"><i class="fa fa-arrows"></i> fa-arrows</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrows-h"><i class="fa fa-arrows-h"></i> fa-arrows-h</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrows-v"><i class="fa fa-arrows-v"></i> fa-arrows-v</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/asterisk"><i class="fa fa-asterisk"></i> fa-asterisk</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/at"><i class="fa fa-at"></i> fa-at</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/car"><i class="fa fa-automobile"></i> fa-automobile  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/ban"><i class="fa fa-ban"></i> fa-ban</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/university"><i class="fa fa-bank"></i> fa-bank  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bar-chart"><i class="fa fa-bar-chart"></i> fa-bar-chart</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bar-chart"><i class="fa fa-bar-chart-o"></i> fa-bar-chart-o  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/barcode"><i class="fa fa-barcode"></i> fa-barcode</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bars"><i class="fa fa-bars"></i> fa-bars</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/beer"><i class="fa fa-beer"></i> fa-beer</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bell"><i class="fa fa-bell"></i> fa-bell</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bell-o"><i class="fa fa-bell-o"></i> fa-bell-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bell-slash"><i class="fa fa-bell-slash"></i> fa-bell-slash</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bell-slash-o"><i class="fa fa-bell-slash-o"></i> fa-bell-slash-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bicycle"><i class="fa fa-bicycle"></i> fa-bicycle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/binoculars"><i class="fa fa-binoculars"></i> fa-binoculars</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/birthday-cake"><i class="fa fa-birthday-cake"></i> fa-birthday-cake</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bolt"><i class="fa fa-bolt"></i> fa-bolt</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bomb"><i class="fa fa-bomb"></i> fa-bomb</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/book"><i class="fa fa-book"></i> fa-book</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bookmark"><i class="fa fa-bookmark"></i> fa-bookmark</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bookmark-o"><i class="fa fa-bookmark-o"></i> fa-bookmark-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/briefcase"><i class="fa fa-briefcase"></i> fa-briefcase</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bug"><i class="fa fa-bug"></i> fa-bug</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/building"><i class="fa fa-building"></i> fa-building</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/building-o"><i class="fa fa-building-o"></i> fa-building-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bullhorn"><i class="fa fa-bullhorn"></i> fa-bullhorn</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bullseye"><i class="fa fa-bullseye"></i> fa-bullseye</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bus"><i class="fa fa-bus"></i> fa-bus</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/taxi"><i class="fa fa-cab"></i> fa-cab  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/calculator"><i class="fa fa-calculator"></i> fa-calculator</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/calendar"><i class="fa fa-calendar"></i> fa-calendar</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/calendar-o"><i class="fa fa-calendar-o"></i> fa-calendar-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/camera"><i class="fa fa-camera"></i> fa-camera</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/camera-retro"><i class="fa fa-camera-retro"></i> fa-camera-retro</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/car"><i class="fa fa-car"></i> fa-car</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-down"><i class="fa fa-caret-square-o-down"></i> fa-caret-square-o-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-left"><i class="fa fa-caret-square-o-left"></i> fa-caret-square-o-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-right"><i class="fa fa-caret-square-o-right"></i> fa-caret-square-o-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-up"><i class="fa fa-caret-square-o-up"></i> fa-caret-square-o-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/cc"><i class="fa fa-cc"></i> fa-cc</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/certificate"><i class="fa fa-certificate"></i> fa-certificate</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/check"><i class="fa fa-check"></i> fa-check</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/level-up"><i class="fa fa-level-up"></i> fa-level-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/life-ring"><i class="fa fa-life-bouy"></i> fa-life-bouy  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/life-ring"><i class="fa fa-life-buoy"></i> fa-life-buoy  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/life-ring"><i class="fa fa-life-ring"></i> fa-life-ring</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/life-ring"><i class="fa fa-life-saver"></i> fa-life-saver  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/lightbulb-o"><i class="fa fa-lightbulb-o"></i> fa-lightbulb-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/line-chart"><i class="fa fa-line-chart"></i> fa-line-chart</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/location-arrow"><i class="fa fa-location-arrow"></i> fa-location-arrow</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/lock"><i class="fa fa-lock"></i> fa-lock</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/magic"><i class="fa fa-magic"></i> fa-magic</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/magnet"><i class="fa fa-magnet"></i> fa-magnet</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/share"><i class="fa fa-mail-forward"></i> fa-mail-forward  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/reply"><i class="fa fa-mail-reply"></i> fa-mail-reply  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/reply-all"><i class="fa fa-mail-reply-all"></i> fa-mail-reply-all  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/male"><i class="fa fa-male"></i> fa-male</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/map-marker"><i class="fa fa-map-marker"></i> fa-map-marker</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/meh-o"><i class="fa fa-meh-o"></i> fa-meh-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/microphone"><i class="fa fa-microphone"></i> fa-microphone</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/microphone-slash"><i class="fa fa-microphone-slash"></i> fa-microphone-slash</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/minus"><i class="fa fa-minus"></i> fa-minus</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/minus-circle"><i class="fa fa-minus-circle"></i> fa-minus-circle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/minus-square"><i class="fa fa-minus-square"></i> fa-minus-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/minus-square-o"><i class="fa fa-minus-square-o"></i> fa-minus-square-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/mobile"><i class="fa fa-mobile"></i> fa-mobile</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/mobile"><i class="fa fa-mobile-phone"></i> fa-mobile-phone  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/money"><i class="fa fa-money"></i> fa-money</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/moon-o"><i class="fa fa-moon-o"></i> fa-moon-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/graduation-cap"><i class="fa fa-mortar-board"></i> fa-mortar-board  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/music"><i class="fa fa-music"></i> fa-music</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bars"><i class="fa fa-navicon"></i> fa-navicon  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/newspaper-o"><i class="fa fa-newspaper-o"></i> fa-newspaper-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/paint-brush"><i class="fa fa-paint-brush"></i> fa-paint-brush</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/paper-plane"><i class="fa fa-paper-plane"></i> fa-paper-plane</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/paper-plane-o"><i class="fa fa-paper-plane-o"></i> fa-paper-plane-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/paw"><i class="fa fa-paw"></i> fa-paw</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/pencil"><i class="fa fa-pencil"></i> fa-pencil</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/pencil-square"><i class="fa fa-pencil-square"></i> fa-pencil-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/pencil-square-o"><i class="fa fa-pencil-square-o"></i> fa-pencil-square-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/phone"><i class="fa fa-phone"></i> fa-phone</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/phone-square"><i class="fa fa-phone-square"></i> fa-phone-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/picture-o"><i class="fa fa-photo"></i> fa-photo  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/picture-o"><i class="fa fa-picture-o"></i> fa-picture-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/pie-chart"><i class="fa fa-pie-chart"></i> fa-pie-chart</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/plane"><i class="fa fa-plane"></i> fa-plane</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/plug"><i class="fa fa-plug"></i> fa-plug</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/plus"><i class="fa fa-plus"></i> fa-plus</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/plus-circle"><i class="fa fa-plus-circle"></i> fa-plus-circle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/plus-square"><i class="fa fa-plus-square"></i> fa-plus-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/plus-square-o"><i class="fa fa-plus-square-o"></i> fa-plus-square-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/power-off"><i class="fa fa-power-off"></i> fa-power-off</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/print"><i class="fa fa-print"></i> fa-print</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/puzzle-piece"><i class="fa fa-puzzle-piece"></i> fa-puzzle-piece</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/qrcode"><i class="fa fa-qrcode"></i> fa-qrcode</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/question"><i class="fa fa-question"></i> fa-question</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/question-circle"><i class="fa fa-question-circle"></i> fa-question-circle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/quote-left"><i class="fa fa-quote-left"></i> fa-quote-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/quote-right"><i class="fa fa-quote-right"></i> fa-quote-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/random"><i class="fa fa-random"></i> fa-random</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/recycle"><i class="fa fa-recycle"></i> fa-recycle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/refresh"><i class="fa fa-refresh"></i> fa-refresh</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/times"><i class="fa fa-remove"></i> fa-remove  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/bars"><i class="fa fa-reorder"></i> fa-reorder  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/reply"><i class="fa fa-reply"></i> fa-reply</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/reply-all"><i class="fa fa-reply-all"></i> fa-reply-all</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/retweet"><i class="fa fa-retweet"></i> fa-retweet</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/road"><i class="fa fa-road"></i> fa-road</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/rocket"><i class="fa fa-rocket"></i> fa-rocket</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/rss"><i class="fa fa-rss"></i> fa-rss</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/rss-square"><i class="fa fa-rss-square"></i> fa-rss-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/search"><i class="fa fa-search"></i> fa-search</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/search-minus"><i class="fa fa-search-minus"></i> fa-search-minus</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/search-plus"><i class="fa fa-search-plus"></i> fa-search-plus</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/paper-plane"><i class="fa fa-send"></i> fa-send  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/paper-plane-o"><i class="fa fa-send-o"></i> fa-send-o  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/share"><i class="fa fa-share"></i> fa-share</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/share-alt"><i class="fa fa-share-alt"></i> fa-share-alt</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/share-alt-square"><i class="fa fa-share-alt-square"></i> fa-share-alt-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/share-square"><i class="fa fa-share-square"></i> fa-share-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/share-square-o"><i class="fa fa-share-square-o"></i> fa-share-square-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/shield"><i class="fa fa-shield"></i> fa-shield</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/shopping-cart"><i class="fa fa-shopping-cart"></i> fa-shopping-cart</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sign-in"><i class="fa fa-sign-in"></i> fa-sign-in</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sign-out"><i class="fa fa-sign-out"></i> fa-sign-out</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/signal"><i class="fa fa-signal"></i> fa-signal</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sitemap"><i class="fa fa-sitemap"></i> fa-sitemap</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sliders"><i class="fa fa-sliders"></i> fa-sliders</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/smile-o"><i class="fa fa-smile-o"></i> fa-smile-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/futbol-o"><i class="fa fa-soccer-ball-o"></i> fa-soccer-ball-o  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort"><i class="fa fa-sort"></i> fa-sort</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort-alpha-asc"><i class="fa fa-sort-alpha-asc"></i> fa-sort-alpha-asc</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort-alpha-desc"><i class="fa fa-sort-alpha-desc"></i> fa-sort-alpha-desc</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort-amount-asc"><i class="fa fa-sort-amount-asc"></i> fa-sort-amount-asc</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort-amount-desc"><i class="fa fa-sort-amount-desc"></i> fa-sort-amount-desc</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort-asc"><i class="fa fa-sort-asc"></i> fa-sort-asc</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort-desc"><i class="fa fa-sort-desc"></i> fa-sort-desc</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort-desc"><i class="fa fa-sort-down"></i> fa-sort-down  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort-numeric-asc"><i class="fa fa-sort-numeric-asc"></i> fa-sort-numeric-asc</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort-numeric-desc"><i class="fa fa-sort-numeric-desc"></i> fa-sort-numeric-desc</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort-asc"><i class="fa fa-sort-up"></i> fa-sort-up  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/space-shuttle"><i class="fa fa-space-shuttle"></i> fa-space-shuttle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/spinner"><i class="fa fa-spinner"></i> fa-spinner</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/spoon"><i class="fa fa-spoon"></i> fa-spoon</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/square"><i class="fa fa-square"></i> fa-square</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/square-o"><i class="fa fa-square-o"></i> fa-square-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/star"><i class="fa fa-star"></i> fa-star</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/star-half"><i class="fa fa-star-half"></i> fa-star-half</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/star-half-o"><i class="fa fa-star-half-empty"></i> fa-star-half-empty  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/star-half-o"><i class="fa fa-star-half-full"></i> fa-star-half-full  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/star-half-o"><i class="fa fa-star-half-o"></i> fa-star-half-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/star-o"><i class="fa fa-star-o"></i> fa-star-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/suitcase"><i class="fa fa-suitcase"></i> fa-suitcase</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sun-o"><i class="fa fa-sun-o"></i> fa-sun-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/life-ring"><i class="fa fa-support"></i> fa-support  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/tablet"><i class="fa fa-tablet"></i> fa-tablet</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/tachometer"><i class="fa fa-tachometer"></i> fa-tachometer</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/tag"><i class="fa fa-tag"></i> fa-tag</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/tags"><i class="fa fa-tags"></i> fa-tags</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/tasks"><i class="fa fa-tasks"></i> fa-tasks</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/taxi"><i class="fa fa-taxi"></i> fa-taxi</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/terminal"><i class="fa fa-terminal"></i> fa-terminal</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/thumb-tack"><i class="fa fa-thumb-tack"></i> fa-thumb-tack</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/thumbs-down"><i class="fa fa-thumbs-down"></i> fa-thumbs-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/thumbs-o-down"><i class="fa fa-thumbs-o-down"></i> fa-thumbs-o-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/thumbs-o-up"><i class="fa fa-thumbs-o-up"></i> fa-thumbs-o-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/thumbs-up"><i class="fa fa-thumbs-up"></i> fa-thumbs-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/ticket"><i class="fa fa-ticket"></i> fa-ticket</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/times"><i class="fa fa-times"></i> fa-times</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/times-circle"><i class="fa fa-times-circle"></i> fa-times-circle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/times-circle-o"><i class="fa fa-times-circle-o"></i> fa-times-circle-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/tint"><i class="fa fa-tint"></i> fa-tint</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-down"><i class="fa fa-toggle-down"></i> fa-toggle-down  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-left"><i class="fa fa-toggle-left"></i> fa-toggle-left  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/toggle-off"><i class="fa fa-toggle-off"></i> fa-toggle-off</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/toggle-on"><i class="fa fa-toggle-on"></i> fa-toggle-on</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-right"><i class="fa fa-toggle-right"></i> fa-toggle-right  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-up"><i class="fa fa-toggle-up"></i> fa-toggle-up  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/trash"><i class="fa fa-trash"></i> fa-trash</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/trash-o"><i class="fa fa-trash-o"></i> fa-trash-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/tree"><i class="fa fa-tree"></i> fa-tree</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/trophy"><i class="fa fa-trophy"></i> fa-trophy</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/truck"><i class="fa fa-truck"></i> fa-truck</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/tty"><i class="fa fa-tty"></i> fa-tty</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/umbrella"><i class="fa fa-umbrella"></i> fa-umbrella</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/university"><i class="fa fa-university"></i> fa-university</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/unlock"><i class="fa fa-unlock"></i> fa-unlock</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/unlock-alt"><i class="fa fa-unlock-alt"></i> fa-unlock-alt</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/sort"><i class="fa fa-unsorted"></i> fa-unsorted  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/upload"><i class="fa fa-upload"></i> fa-upload</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/user"><i class="fa fa-user"></i> fa-user</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/users"><i class="fa fa-users"></i> fa-users</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/video-camera"><i class="fa fa-video-camera"></i> fa-video-camera</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/volume-down"><i class="fa fa-volume-down"></i> fa-volume-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/volume-off"><i class="fa fa-volume-off"></i> fa-volume-off</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/volume-up"><i class="fa fa-volume-up"></i> fa-volume-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/exclamation-triangle"><i class="fa fa-warning"></i> fa-warning  </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/wheelchair"><i class="fa fa-wheelchair"></i> fa-wheelchair</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/wifi"><i class="fa fa-wifi"></i> fa-wifi</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/wrench"><i class="fa fa-wrench"></i> fa-wrench</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- row -->
                     <div class="row">
                        <!-- Gallery section -->
                        <div class="col-md-12">
                           <div class="white_shd full margin_bottom_30">
                              <div class="full graph_head">
                                 <div class="heading1 margin_0">
                                    <h2>Files Icons</h2>
                                 </div>
                              </div>
                              <div class="full icons_section padding_infor_info">
                                 <div class="row fontawesome-icons-list">
                                    <div class="fw_icon"><a href="#/file"><i class="fa fa-file"></i> fa-file</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-archive-o"><i class="fa fa-file-archive-o"></i> fa-file-archive-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-audio-o"><i class="fa fa-file-audio-o"></i> fa-file-audio-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-code-o"><i class="fa fa-file-code-o"></i> fa-file-code-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-excel-o"><i class="fa fa-file-excel-o"></i> fa-file-excel-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-image-o"><i class="fa fa-file-image-o"></i> fa-file-image-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-video-o"><i class="fa fa-file-movie-o"></i> fa-file-movie-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-o"><i class="fa fa-file-o"></i> fa-file-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-pdf-o"><i class="fa fa-file-pdf-o"></i> fa-file-pdf-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-image-o"><i class="fa fa-file-photo-o"></i> fa-file-photo-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-image-o"><i class="fa fa-file-picture-o"></i> fa-file-picture-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-powerpoint-o"><i class="fa fa-file-powerpoint-o"></i> fa-file-powerpoint-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-audio-o"><i class="fa fa-file-sound-o"></i> fa-file-sound-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-text"><i class="fa fa-file-text"></i> fa-file-text</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-text-o"><i class="fa fa-file-text-o"></i> fa-file-text-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-video-o"><i class="fa fa-file-video-o"></i> fa-file-video-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-word-o"><i class="fa fa-file-word-o"></i> fa-file-word-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/file-archive-o"><i class="fa fa-file-zip-o"></i> fa-file-zip-o</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- row -->
                     <div class="row">
                        <!-- Gallery section -->
                        <div class="col-md-12">
                           <div class="white_shd full margin_bottom_30">
                              <div class="full graph_head">
                                 <div class="heading1 margin_0">
                                    <h2>Video Player Icons</h2>
                                 </div>
                              </div>
                              <div class="full icons_section padding_infor_info">
                                 <div class="row fontawesome-icons-list">
                                    <div class="fw_icon"><a href="#/arrows-alt"><i class="fa fa-arrows-alt"></i> fa-arrows-alt</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/backward"><i class="fa fa-backward"></i> fa-backward</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/compress"><i class="fa fa-compress"></i> fa-compress</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/eject"><i class="fa fa-eject"></i> fa-eject</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/expand"><i class="fa fa-expand"></i> fa-expand</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/fast-backward"><i class="fa fa-fast-backward"></i> fa-fast-backward</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/fast-forward"><i class="fa fa-fast-forward"></i> fa-fast-forward</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/forward"><i class="fa fa-forward"></i> fa-forward</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/pause"><i class="fa fa-pause"></i> fa-pause</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/play"><i class="fa fa-play"></i> fa-play</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/play-circle"><i class="fa fa-play-circle"></i> fa-play-circle</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/play-circle-o"><i class="fa fa-play-circle-o"></i> fa-play-circle-o</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/step-backward"><i class="fa fa-step-backward"></i> fa-step-backward</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/step-forward"><i class="fa fa-step-forward"></i> fa-step-forward</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/stop"><i class="fa fa-stop"></i> fa-stop</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/youtube-play"><i class="fa fa-youtube-play"></i> fa-youtube-play</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- row -->
                     <div class="row">
                        <!-- Gallery section -->
                        <div class="col-md-12">
                           <div class="white_shd full margin_bottom_30">
                              <div class="full graph_head">
                                 <div class="heading1 margin_0">
                                    <h2>Arrow Icons</h2>
                                 </div>
                              </div>
                              <div class="full icons_section padding_infor_info">
                                 <div class="row fontawesome-icons-list">
                                    <div class="fw_icon"><a href="#/angle-double-down"><i class="fa fa-angle-double-down"></i> fa-angle-double-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/angle-double-left"><i class="fa fa-angle-double-left"></i> fa-angle-double-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/angle-double-right"><i class="fa fa-angle-double-right"></i> fa-angle-double-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/angle-double-up"><i class="fa fa-angle-double-up"></i> fa-angle-double-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/angle-down"><i class="fa fa-angle-down"></i> fa-angle-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/angle-left"><i class="fa fa-angle-left"></i> fa-angle-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/angle-right"><i class="fa fa-angle-right"></i> fa-angle-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/angle-up"><i class="fa fa-angle-up"></i> fa-angle-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-circle-down"><i class="fa fa-arrow-circle-down"></i> fa-arrow-circle-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-circle-left"><i class="fa fa-arrow-circle-left"></i> fa-arrow-circle-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-circle-o-down"><i class="fa fa-arrow-circle-o-down"></i> fa-arrow-circle-o-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-circle-o-left"><i class="fa fa-arrow-circle-o-left"></i> fa-arrow-circle-o-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-circle-o-right"><i class="fa fa-arrow-circle-o-right"></i> fa-arrow-circle-o-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-circle-o-up"><i class="fa fa-arrow-circle-o-up"></i> fa-arrow-circle-o-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-circle-right"><i class="fa fa-arrow-circle-right"></i> fa-arrow-circle-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-circle-up"><i class="fa fa-arrow-circle-up"></i> fa-arrow-circle-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-down"><i class="fa fa-arrow-down"></i> fa-arrow-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-left"><i class="fa fa-arrow-left"></i> fa-arrow-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-right"><i class="fa fa-arrow-right"></i> fa-arrow-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrow-up"><i class="fa fa-arrow-up"></i> fa-arrow-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrows"><i class="fa fa-arrows"></i> fa-arrows</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrows-alt"><i class="fa fa-arrows-alt"></i> fa-arrows-alt</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrows-h"><i class="fa fa-arrows-h"></i> fa-arrows-h</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/arrows-v"><i class="fa fa-arrows-v"></i> fa-arrows-v</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-down"><i class="fa fa-caret-down"></i> fa-caret-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-left"><i class="fa fa-caret-left"></i> fa-caret-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-right"><i class="fa fa-caret-right"></i> fa-caret-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-down"><i class="fa fa-caret-square-o-down"></i> fa-caret-square-o-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-left"><i class="fa fa-caret-square-o-left"></i> fa-caret-square-o-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-right"><i class="fa fa-caret-square-o-right"></i> fa-caret-square-o-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-up"><i class="fa fa-caret-square-o-up"></i> fa-caret-square-o-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-up"><i class="fa fa-caret-up"></i> fa-caret-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/chevron-circle-down"><i class="fa fa-chevron-circle-down"></i> fa-chevron-circle-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/chevron-circle-left"><i class="fa fa-chevron-circle-left"></i> fa-chevron-circle-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/chevron-circle-right"><i class="fa fa-chevron-circle-right"></i> fa-chevron-circle-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/chevron-circle-up"><i class="fa fa-chevron-circle-up"></i> fa-chevron-circle-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/chevron-down"><i class="fa fa-chevron-down"></i> fa-chevron-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/chevron-left"><i class="fa fa-chevron-left"></i> fa-chevron-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/chevron-right"><i class="fa fa-chevron-right"></i> fa-chevron-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/chevron-up"><i class="fa fa-chevron-up"></i> fa-chevron-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/hand-o-down"><i class="fa fa-hand-o-down"></i> fa-hand-o-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/hand-o-left"><i class="fa fa-hand-o-left"></i> fa-hand-o-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/hand-o-right"><i class="fa fa-hand-o-right"></i> fa-hand-o-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/hand-o-up"><i class="fa fa-hand-o-up"></i> fa-hand-o-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/long-arrow-down"><i class="fa fa-long-arrow-down"></i> fa-long-arrow-down</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/long-arrow-left"><i class="fa fa-long-arrow-left"></i> fa-long-arrow-left</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/long-arrow-right"><i class="fa fa-long-arrow-right"></i> fa-long-arrow-right</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/long-arrow-up"><i class="fa fa-long-arrow-up"></i> fa-long-arrow-up</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-down"><i class="fa fa-toggle-down"></i> fa-toggle-down </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-left"><i class="fa fa-toggle-left"></i> fa-toggle-left </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-right"><i class="fa fa-toggle-right"></i> fa-toggle-right </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/caret-square-o-up"><i class="fa fa-toggle-up"></i> fa-toggle-up </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- row -->
                     <div class="row">
                        <!-- Gallery section -->
                        <div class="col-md-12">
                           <div class="white_shd full margin_bottom_30">
                              <div class="full graph_head">
                                 <div class="heading1 margin_0">
                                    <h2>Currency Icons</h2>
                                 </div>
                              </div>
                              <div class="full icons_section padding_infor_info">
                                 <div class="row fontawesome-icons-list">
                                    <div class="fw_icon"><a href="#/btc"><i class="fa fa-bitcoin"></i> fa-bitcoin </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/btc"><i class="fa fa-btc"></i> fa-btc</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/jpy"><i class="fa fa-cny"></i> fa-cny </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/usd"><i class="fa fa-dollar"></i> fa-dollar </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/eur"><i class="fa fa-eur"></i> fa-eur</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/eur"><i class="fa fa-euro"></i> fa-euro </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/gbp"><i class="fa fa-gbp"></i> fa-gbp</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/ils"><i class="fa fa-ils"></i> fa-ils</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/inr"><i class="fa fa-inr"></i> fa-inr</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/jpy"><i class="fa fa-jpy"></i> fa-jpy</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/krw"><i class="fa fa-krw"></i> fa-krw</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/money"><i class="fa fa-money"></i> fa-money</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/jpy"><i class="fa fa-rmb"></i> fa-rmb </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/rub"><i class="fa fa-rouble"></i> fa-rouble </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/rub"><i class="fa fa-rub"></i> fa-rub</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/rub"><i class="fa fa-ruble"></i> fa-ruble </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/inr"><i class="fa fa-rupee"></i> fa-rupee </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/ils"><i class="fa fa-shekel"></i> fa-shekel </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/ils"><i class="fa fa-sheqel"></i> fa-sheqel </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/try"><i class="fa fa-try"></i> fa-try</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/try"><i class="fa fa-turkish-lira"></i> fa-turkish-lira </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/usd"><i class="fa fa-usd"></i> fa-usd</a>
                                    </div>
                                    <div class="fw_icon"><a href="#/krw"><i class="fa fa-won"></i> fa-won </a>
                                    </div>
                                    <div class="fw_icon"><a href="#/jpy"><i class="fa fa-yen"></i> fa-yen </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                <!-- footer Layout Here-->
               </div>
               <!-- end dashboard inner -->
            </div>
         </div>
         <!-- model popup -->
         <!-- The Modal -->
         <div class="modal fade" id="myModal">
            <div class="modal-dialog">
               <div class="modal-content">
                  <!-- Modal Header -->
                  <div class="modal-header">
                     <h4 class="modal-title">Modal Heading</h4>
                     <button type="button" class="close" data-dismiss="modal">&times;</button>
                  </div>
                  <!-- Modal body -->
                  <div class="modal-body">
                     Modal body..
                  </div>
                  <!-- Modal footer -->
                  <div class="modal-footer">
                     <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                  </div>
               </div>
            </div>
         </div>
         <!-- end model popup -->
      </div>
	   
      <!-- jQuery -->
      <script src="{{url('backend/assets/js/jquery.min.js')}}"></script>
      <script src="{{url('backend/assets/js/popper.min.js')}}"></script>
      <script src="{{url('backend/assets/js/bootstrap.min.js')}}"></script>
      <!-- wow animation -->
      <script src="{{url('backend/assets/js/animate.js')}}"></script>
      <!-- select country -->
      <script src="{{url('backend/assets/js/bootstrap-select.js')}}"></script>
      <!-- owl carousel -->
      <script src="{{url('backend/assets/js/owl.carousel.js')}}"></script> 
      <!-- chart js -->
      <script src="{{url('backend/assets/js/Chart.min.js')}}"></script>
      <script src="{{url('backend/assets/js/Chart.bundle.min.js')}}"></script>
      <script src="{{url('backend/assets/js/utils.js')}}"></script>
      <script src="{{url('backend/assets/js/analyser.js')}}"></script>
      <!-- nice scrollbar -->
      <script src="{{url('backend/assets/js/perfect-scrollbar.min.js')}}"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- fancy box js -->
      <script src="{{url('backend/assets/js/jquery-3.3.1.min.js')}}"></script>
      <script src="{{url('backend/assets/js/jquery.fancybox.min.js')}}"></script>
      <!-- custom js -->
      <script src="{{url('backend/assets/js/custom.js')}}"></script>
      <!-- calendar file css -->    
      <script src="{{url('backend/assets/js/semantic.min.js')}}"></script>
   </body>
</html> @endsection