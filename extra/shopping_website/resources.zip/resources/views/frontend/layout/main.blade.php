@include('frontend.layout.header')
@yield('main_container')
@include('frontend.layout.footer')

