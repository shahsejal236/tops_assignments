<?php echo $__env->make('backend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main_container'); ?>
<?php /**PATH C:\new xampp\htdocs\sejal\laravel\empmanagement\resources\views/backend/layout/main.blade.php ENDPATH**/ ?>