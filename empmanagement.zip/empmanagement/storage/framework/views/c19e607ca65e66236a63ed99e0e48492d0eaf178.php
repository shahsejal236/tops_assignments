

<?php $__env->startSection('main_container'); ?>


<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Carousel Start -->
    


    <?php if(session('success')): ?>
						<span class="alert alert-success"><?php echo e(session('success')); ?></span>
	<?php endif; ?>	

    <!-- Testimonial Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="text-center">
                <h6 class="text-secondary text-uppercase">User Profile</h6>
                <h1 class="mb-5">View Profile</h1>
            </div>
            <div class="owl-carousel testimonial-carousel position-relative wow fadeInUp" data-wow-delay="0.1s">
                
            <div class="testimonial-item text-center">
                   
                </div>
            </div>
        </div>

        <div class="testimonial-item text-center">
                    <div class="testimonial-text bg-light text-center p-4 mb-4">
                        <p class="mb-0">Hello </p>
                    </div>
                   
                    <div class="mb-2">
                        <small class="fa fa-star text-secondary"></small>
                        <small class="fa fa-star text-secondary"></small>
                        <small class="fa fa-star text-secondary"></small>
                        <small class="fa fa-star text-secondary"></small>
                        <small class="fa fa-star text-secondary"></small>
                    </div>
                    <h5 class="mb-1"> <?php echo e(session('fname')); ?></h5>
                    <p class="m-0"><?php echo e(session('email')); ?></p>
                </div>
            </div>
        </div>


    </div>
    <!-- Testimonial End -->


   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\new xampp\htdocs\sejal\laravel\empmanagement\resources\views/frontend/profile.blade.php ENDPATH**/ ?>