

<?php $__env->startSection('main_container'); ?> 



<!-- TEAM -->
<section id="team" class="parallax-section">
     <div class="container">
          <div class="row">

               <div class="col-md-offset-2 col-md-8 col-sm-12">
                    <!-- SECTION TITLE -->
                    <div class="section-title">
                         <h1>Image Gallery</h1>
                    </div>
               </div>			
		
			<div id="owl-team" class="owl-carousel">
					<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-sm-4 item">
                         <div class="team-item">
                              <img src="<?php echo e(url('upload/photo/'.$d->file)); ?>" class="img-responsive" alt="">
							  <h3><?php echo e($d->photo_name); ?></h3>							  
                         </div>         
						 
                    </div>
					
      
	
                    <div class="col-md-4 col-sm-4 item">
                         <div class="team-item">       
							   <?php
							   $multi_file=$d->multi_file;
							   $multi_filearr=explode(',',$multi_file);
							   ?>
                        <?php $__currentLoopData = $multi_filearr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $multi_file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<img src="<?php echo e(url('upload/multi_photo/'.$multi_file)); ?>" class="img-responsive" alt="">  
							<h3><?php echo e($d->photo_name); ?></h3>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
                         </div>         
					</div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
			</div>
	
		
     </div>
	 </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sejal\laravel\laravel_assi\resources\views/frontend/photo_gallary.blade.php ENDPATH**/ ?>