<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Photographer | HTML Template</title>
	<meta charset="UTF-8">
	<meta name="description" content="Photographer html template">
	<meta name="keywords" content="photographer, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Favicon -->
	<link href="frontend/img/favicon.ico" rel="shortcut icon"/>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i&display=swap" rel="stylesheet">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="frontend/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="frontend/font-awesome.min.css"/>
	<link rel="stylesheet" href="frontend/css/magnific-popup.css"/>
	<link rel="stylesheet" href="frontend/slicknav.min.css"/>
	<link rel="stylesheet" href="frontend/owl.carousel.min.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="frontend/css/style.css"/>


	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- Header section  -->
	<header class="header-section hs-bd">
		<a href="index.html" class="site-logo"><img src="img/logo.png" alt="logo"></a>
		<div class="header-controls">
			<button class="nav-switch-btn"><i class="fa fa-bars"></i></button>
			<button class="search-btn"><i class="fa fa-search"></i></button>
		</div>
		<ul class="main-menu">
			<li><a href="index.html">Home</a></li>
			<li><a href="about.html">About the Artist </a></li>
			<li>
				<a href="#">Portfolio</a>
				<ul class="sub-menu">
					<li><a href="portfolio.html">Portfolio 1</a></li>
					<li><a href="portfolio-1.html">Portfolio 2</a></li>
					<li><a href="portfolio-2.html">Portfolio 3</a></li>
				</ul>
			</li>
			<li><a href="blog.html">Blog</a></li>
			<li><a href="elements.html">Elements</a></li>
			<li><a href="contact.html">Contact</a></li>
			<li class="search-mobile">
				<button class="search-btn"><i class="fa fa-search"></i></button>
			</li>
		</ul>
	</header>
	<div class="clearfix"></div>
	<!-- Header section end  -->

	<!-- Blog section  -->
	<section class="blog-section">
		<div class="blog-warp">
			<div class="row">
				<div class="col-lg-4 col-sm-6">
					<div class="blog-post">
						<img src="img/blog/1.jpg" alt="">
						<div class="blog-date">Feb 11, 2019</div>
						<h3>10 Tips for a great shot</h3>
						<div class="blog-cata">
							<span>Lifestyle</span>
							<span>Photography</span>
							<span>Travel</span>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incidi-dunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas.</p>
						<a href="" class="site-btn">Read more</a>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="blog-post">
						<img src="img/blog/2.jpg" alt="">
						<div class="blog-date">Feb 11, 2019</div>
						<h3>Photography cousrses 101</h3>
						<div class="blog-cata">
							<span>Lifestyle</span>
							<span>Photography</span>
							<span>Travel</span>
						</div>
						<p>Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravi-da. Risus commodo viverra maecenas ac-cumsan lacus vel facilisis.</p>
						<a href="" class="site-btn">Read more</a>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="blog-post">
						<img src="img/blog/3.jpg" alt="">
						<div class="blog-date">Feb 11, 2019</div>
						<h3>New Lifestyle event</h3>
						<div class="blog-cata">
							<span>Lifestyle</span>
							<span>Photography</span>
							<span>Travel</span>
						</div>
						<p>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum sus-pendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facili-sis commodo viverra maecenas. </p>
						<a href="" class="site-btn">Read more</a>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="blog-post">
						<img src="img/blog/4.jpg" alt="">
						<div class="blog-date">Feb 11, 2019</div>
						<h3>10 Tips for a great shot</h3>
						<div class="blog-cata">
							<span>Lifestyle</span>
							<span>Photography</span>
							<span>Travel</span>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incidi-dunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas.</p>
						<a href="" class="site-btn">Read more</a>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="blog-post">
						<img src="img/blog/5.jpg" alt="">
						<div class="blog-date">Feb 11, 2019</div>
						<h3>Photography cousrses 101</h3>
						<div class="blog-cata">
							<span>Lifestyle</span>
							<span>Photography</span>
							<span>Travel</span>
						</div>
						<p>Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravi-da. Risus commodo viverra maecenas ac-cumsan lacus vel facilisis.</p>
						<a href="" class="site-btn">Read more</a>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="blog-post">
						<img src="img/blog/6.jpg" alt="">
						<div class="blog-date">Feb 11, 2019</div>
						<h3>New Lifestyle event</h3>
						<div class="blog-cata">
							<span>Lifestyle</span>
							<span>Photography</span>
							<span>Travel</span>
						</div>
						<p>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum sus-pendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facili-sis commodo viverra maecenas. </p>
						<a href="" class="site-btn">Read more</a>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="blog-post">
						<img src="img/blog/7.jpg" alt="">
						<div class="blog-date">Feb 11, 2019</div>
						<h3>10 Tips for a great shot</h3>
						<div class="blog-cata">
							<span>Lifestyle</span>
							<span>Photography</span>
							<span>Travel</span>
						</div>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incidi-dunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas.</p>
						<a href="" class="site-btn">Read more</a>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="blog-post">
						<img src="img/blog/8.jpg" alt="">
						<div class="blog-date">Feb 11, 2019</div>
						<h3>Photography cousrses 101</h3>
						<div class="blog-cata">
							<span>Lifestyle</span>
							<span>Photography</span>
							<span>Travel</span>
						</div>
						<p>Consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravi-da. Risus commodo viverra maecenas ac-cumsan lacus vel facilisis.</p>
						<a href="" class="site-btn">Read more</a>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="blog-post">
						<img src="img/blog/9.jpg" alt="">
						<div class="blog-date">Feb 11, 2019</div>
						<h3>New Lifestyle event</h3>
						<div class="blog-cata">
							<span>Lifestyle</span>
							<span>Photography</span>
							<span>Travel</span>
						</div>
						<p>Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum sus-pendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facili-sis commodo viverra maecenas. </p>
						<a href="" class="site-btn">Read more</a>
					</div>
				</div>
			</div>
			<div class="site-pagination">
				<a href="" class="current">01.</a>
				<a href="">02.</a>
				<a href="">03.</a>
				<a href="">04.</a>
				<a href="">05.</a>
			</div>
		</div>
	</section>
	<!-- Blog section end  -->
	
	<!-- Footer section   -->
	<footer class="footer-section">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6 order-1 order-md-2">
					<div class="footer-social-links">
						<a href=""><i class="fa fa-pinterest"></i></a>
						<a href=""><i class="fa fa-facebook"></i></a>
						<a href=""><i class="fa fa-twitter"></i></a>
						<a href=""><i class="fa fa-dribbble"></i></a>
						<a href=""><i class="fa fa-behance"></i></a>
					</div>
				</div>
				<div class="col-md-6 order-2 order-md-1">
					<div class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
</div>	
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer section end  -->

	<!-- Search model -->
	<div class="search-model">
		<div class="h-100 d-flex align-items-center justify-content-center">
			<div class="search-close-switch">+</div>
			<form class="search-model-form">
				<input type="text" id="search-input" placeholder="Search here.....">
			</form>
		</div>
	</div>
	<!-- Search model end -->

	<!--====== Javascripts & Jquery ======-->
	<script src="frontend/js/jquery-3.2.1.min.js"></script>
	<script src="frontend/js/bootstrap.min.js"></script>
	<script src="frontend/js/jquery.slicknav.min.js"></script>
	<script src="frontend/js/owl.carousel.min.js"></script>
	<script src="frontend/js/jquery.magnific-popup.min.js"></script>
	<script src="frontend/js/circle-progress.min.js"></script>
	<script src="frontend/js/mixitup.min.js"></script>
	<script src="frontend/js/instafeed.min.js"></script>
	<script src="frontend/js/masonry.pkgd.min.js"></script>
	<script src="frontend/js/main.js"></script>

	</body>
</html>
<?php /**PATH C:\xampp\htdocs\sejal\laravel\laravel_assi\resources\views/frontend/blog.blade.php ENDPATH**/ ?>