@include('backend.layout.header')
@yield('main_container')
@include('backend.layout.footer')