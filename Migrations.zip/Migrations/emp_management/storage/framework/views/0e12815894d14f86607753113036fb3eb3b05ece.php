

<?php $__env->startSection('main_container'); ?>
        <!--  page-wrapper -->
        <div id="page-wrapper">

            
            <div class="row">
                 <!--  page header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Tables</h1>
                </div>
                 <!-- end  page header -->
            </div>
            <form action="<?php echo e(url('/manage_user')); ?>" method="post">
                <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
           
                       
                        <div class="panel-body">
                       
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <?php if($employee): ?>
                                    <thead>
                                        <tr>
                                            <th>Emploee Id</th>
                                            <th>Employee Fname</th>
                                            <th>Employee lname</th>
                                            <th>Gender</th>
                                            <th>Phone No</th>
                                            <th>Age</th>
                                            <th>Address</th>
                                            <th>Email Id</th>
                                            <th>Password</th>
                                            <th>Edit</th>
                                            <th>Delete</th>

                                        </tr>
                                    </thead>    
                                    
                                    <tbody>
                                   
                                    <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="odd gradeX">
                                            <td><?php echo e($emp->id); ?></td>
                                            <td><?php echo e($emp->fname); ?></td>
                                            <td><?php echo e($emp->lname); ?></td>
                                            <td><?php echo e($emp->gender); ?></td>
                                            <td><?php echo e($emp->phone_no); ?></td>
                                            <td><?php echo e($emp->age); ?></td>
                                            <td><?php echo e($d->address); ?></td>
                                            <td><?php echo e($d->email); ?></td>
                                            <td><?php echo e($d->password); ?></td>
                                            <td></td>
                                            <td></td>

                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                    <?php endif; ?>
                                </table>
                                
                       
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>
            
                
          
        </div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/plugins/pace/pace.js"></script>
    <script src="assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="assets/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="assets/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {
            $('#dataTables-example').dataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('backend.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sejal\laravel\emp_management\resources\views/backend/manage_employee.blade.php ENDPATH**/ ?>