<?php echo $__env->make('backend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main_container'); ?>
<?php /**PATH C:\xampp\htdocs\sejal\laravel\emp_management\resources\views/backend/layout/main.blade.php ENDPATH**/ ?>